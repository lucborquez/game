package com.esports.game_service.dto;

import jakarta.validation.constraints.*;

public class JuegoRequestDTO {

    @NotBlank(message = "El nombre es obligatorio")
    private String nombre;

    @NotBlank(message = "El género es obligatorio")
    private String genero;

    @NotBlank(message = "La modalidad es obligatoria")
    private String modalidad;

    @NotNull(message = "Los jugadores por equipo son obligatorios")
    @Positive(message = "Debe ser un número positivo")
    private Integer jugadoresPorEquipo;

    // Getters y Setters
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getGenero() { return genero; }
    public void setGenero(String genero) { this.genero = genero; }

    public String getModalidad() { return modalidad; }
    public void setModalidad(String modalidad) { this.modalidad = modalidad; }

    public Integer getJugadoresPorEquipo() { return jugadoresPorEquipo; }
    public void setJugadoresPorEquipo(Integer jugadoresPorEquipo) { this.jugadoresPorEquipo = jugadoresPorEquipo; }
}